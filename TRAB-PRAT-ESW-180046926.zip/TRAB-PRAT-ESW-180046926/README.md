# Projeto-Engenharia-de-Software-
Trabalho Prático desenvolvido para a  disciplina de Engenharia de Software da Universidade de Brasília no semestre 2/2020.

### Participantes do Projeto 

|Projeto Engenharia de Software|  |
|--|--|
| Mariana Borges de Sampaio|  180046926 |

## Descrição do Projeto 

O projeto consiste na construção de artefatos que são construídos no processo de desenvolvimento de software. Esse processo será embasado no processo que é feito no OpenUP. 
O sistema de software desenvolvido tem como objetivo realizar o aluguel de imóveis. Para esse sistema serão desenvolvidos: wireframe, prototype e mockup.

## Ferramentas utilizadas 

### Documentação 

- OpenUp

### Banco de Dados 

- DB Browser SQLite 
- MySQL Workbench

### Linguagem de Programação

- SQLite 
- SQL
- HTML 
- CSS

### Modelo de caso de uso 

- Astah 

### Wireframes 
- Adobe XD
### Protótipo 
- Sublime text
### Mockups 
- Sublime text
